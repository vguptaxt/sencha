# Require any additional compass plugins here.
css_dir = "tmp"
sass_dir = "sass"
images_dir = "assets/images"
javascripts_dir = "assets/javascripts"
# Set this to the root of your project when deployed:
http_path = "/"
# To enable relative paths to assets via compass helper functions. Uncomment:
relative_assets = true

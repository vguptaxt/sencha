require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('nextmat', 'compass-960-plugin', 'ninesixty')


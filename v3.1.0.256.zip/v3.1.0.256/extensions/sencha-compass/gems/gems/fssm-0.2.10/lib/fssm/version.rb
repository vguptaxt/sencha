module FSSM
  VERSION = "0.2.10"
end
